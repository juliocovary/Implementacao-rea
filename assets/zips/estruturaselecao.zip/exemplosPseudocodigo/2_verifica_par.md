## Verifica se valor é par

**variavel** *entrada* = **ler**("Digite um valor inteiro:");<br>
**variavel** *x* = **converterInteiro**(*entrada*);

>Verifica **SE** o resto da divisao eh 0 (par)

**se** ((*x* % 2) == 0)<br>
&emsp;&emsp;**console.escreva**("*x* eh um valor Par");<br>
**fim-se**

>**SE NÃO** for par, executa outro código

**se não**
    **console.escreva**("*x* eh um valor Impar");
**fim-se não**