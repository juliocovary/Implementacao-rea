## Imprime alerta de habilitacao

**variavel** *entrada* = **escreva**("Digite sua idade:");

**variavel** *idade* = 0;<br>
*idade* = **converterInteiro**(*entrada*);<br>

>Verifica **SE** idade entrada é maior que 18

**se** (*idade* >= 18)<br>
&emsp;&emsp;**console.escreva**("Parabens! Voce pode possuir uma habilitacao!");<br>
**fim-se**

**console.escreva**("Sua idade é: *idade*");