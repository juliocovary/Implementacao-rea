## Verifica o maior valor

**variavel** *entrada1* = **ler**("Digite um valor inteiro para x:");<br>
**variavel** *entrada2* = **ler**("Digite um valor inteiro para y:");

**variavel** *x* = **converterInteiro**(*entrada1*);<br>
**variavel** *y* = **converterInteiro**(*entrada2*);

>Verifica **SE** *x* eh maior que *y*

**se** (*x* > *y*)<br>
&emsp;&emsp;**console.escreva**("*x* eh maior que *y*");<br>
**fim-se**

>**SE NAO**, verifica **SE** *x* eh menor que *y* 

**se não se** (*x* < *y*)<br>
&emsp;&emsp;**console.escreva**("*y* eh maior que *x*");<br>
**fim-se não se**

>**SE NAO**, imprime que sao valores iguais

**se não**<br>
&emsp;&emsp;**console.escreva**("Os valores são iguais");<br>
**fim-se não**