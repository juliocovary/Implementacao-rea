// função que imprime mensagem : "Hello World"
function impMessage(){              // define a função
    console.log("Hello World");
}

impMessage();       // chama a função e muda o fluxo de execução