## Função que imprime mensagem: "Hello World"

> Definindo a assinatura e corpo da função

**funcao** *imprimeMensagem* ()<br>
&emsp;&emsp;**console.escreva**("Hello World");<br>
**fim-imprimeMensagem**

>Chama a função *imprimeMensagem* e muda o fluxo de execução

**imprimeMensagem**();