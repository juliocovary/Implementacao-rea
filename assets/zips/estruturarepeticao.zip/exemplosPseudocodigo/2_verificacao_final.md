## Imprime sequência numérica

### Verificação no final: fazer-enquanto (do-while)

**variavel** *n* = 0;

>Inicializa o laço sem verificar a condição

**fazer**<br>
&emsp;&emsp;**console.escreva**(*n*);<br>
&emsp;&emsp;*n*++;<br>
**fim-enquanto** (*n* <= 10);

**console.escreva**("Valor final de n: *n*");