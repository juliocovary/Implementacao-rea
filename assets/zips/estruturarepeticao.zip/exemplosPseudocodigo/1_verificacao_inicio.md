## Imprime sequência numérica

### Verificação no início: enquanto (while)

**variavel** *n* = 0;

>Verifica a condição antes de iniciar o laço

**enquanto** (*n* <= 10)<br>
&emsp;&emsp;**console.escreva**(*n*);<br>
&emsp;&emsp;*n*++;<br>
**fim-enquanto**

**console.escreva**("Valor final de n: *n*");