## Imprime sequência numérica

### Estrutura de repetição: para (for)

**variavel** *n* = 0;

**para** (**variavel** *i* = 0; *i* <= 10; *i*++)<br>
&emsp;&emsp;**console.escreva**(*n*);<br>
&emsp;&emsp;*n*++;<br>
**fim-para**