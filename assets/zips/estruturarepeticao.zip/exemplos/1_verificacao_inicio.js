// imprime sequencia numérica

// Verificacao no inicio (while)
let n = 0;

// verifica a condição antes de iniciar o laço
while(n <= 10){
    console.log(n);
    n++;
}

console.log("Valor final de n: " + n);