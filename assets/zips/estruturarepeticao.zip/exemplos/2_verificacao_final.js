// imprime sequencia numérica

// Verificacao no final (do-while)
let n = 0;

// inicializa o laço sem verificar a condição
do{      
    console.log(n);
    n++;
} while(n <= 10);

console.log("Valor final de n: " + n);