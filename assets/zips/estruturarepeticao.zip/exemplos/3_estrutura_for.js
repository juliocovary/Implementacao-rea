// imprime sequencia numérica

// Estrutura de repeticao (for)
let n = 0;

for(let i = 0; i <= 10; i++){
    console.log(n);
    n++;
}