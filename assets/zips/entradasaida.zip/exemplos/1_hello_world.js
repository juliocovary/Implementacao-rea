// imprime "hello world"
console.log("Hello World");