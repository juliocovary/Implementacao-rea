// imprime nome do usuário
let nome = "";
nome = prompt("Digite seu nome:");  // atribuicao da variavel nome com a resposta do prompt

console.log("Ola "+nome);           // imprime a concatenacao de um texto com a resposta. ex: "Ola Lucas"