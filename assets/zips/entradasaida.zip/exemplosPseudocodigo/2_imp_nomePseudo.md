## Imprime nome do usuário

> **ler()** faz a entrada de dados

**variavel** *nome* = "";<br>
*nome* = **ler**("Digite seu nome:");

**console.escreva**("Ola *nome*");