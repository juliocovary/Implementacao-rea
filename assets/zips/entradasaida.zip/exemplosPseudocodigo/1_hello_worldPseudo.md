## Imprime "hello world"

> **console.escreva()** imprime o texto no console

**console.escreva**("Hello World");