// imprimindo um elemento do vetor
let vet = [1, 2, 3, 4, 5];

console.log("Indice: 0 | Valor: " + vet[0]);	// acessando conteúdo do índice 0
console.log("Indice: 1 | Valor: " + vet[1]);	// acessando conteúdo do índice 1
console.log("Indice: 2 | Valor: " + vet[2]);	// acessando conteúdo do índice 2

console.log(vet);       // imprime todo o vetor