## Imprimindo um elemento do vetor

**variavel** *vet* = [1, 2, 3, 4, 5];

>Acessando conteúdo dos índices 0, 1 e 2

**console.escreva**("Indice: 0 | Valor: *vet*[0]");<br>
**console.escreva**("Indice: 1 | Valor: *vet*[1]");<br>
**console.escreva**("Indice: 2 | Valor: *vet*[2]");


> Imprime todo o vetor

**console.escreva**(*vet*);